import re

def analyze_cv(file_path):
    """Analyser le CV et extraire les compétences clés."""
    skills = []
    try:
        # Lecture du fichier avec gestion d'encodage
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
        # Extraction des compétences à partir du contenu
        skills = re.findall(r"\b(Java|Python|SQL|AI|ML|FastAPI|Docker)\b", content, re.IGNORECASE)
    except FileNotFoundError:
        print("Erreur : Fichier introuvable.")
    except Exception as e:
        print(f"Erreur lors de l'analyse du fichier CV : {e}")
    return list(set(skills))  # Supprime les doublons

def extract_skills_from_offer(description):
    """Extraire les compétences des descriptions d'offre."""
    skills_keywords = [
        "Python", "Java", "C#", "SQL", "JavaScript", "AWS", "Azure",
        "Docker", "Kubernetes", "DevOps", "Machine Learning", "Data Science",
        "React", "Angular", "Node.js", "Flask", "Django", "Ruby", "AI",
        "Blockchain", "Cybersecurity", "Big Data", "RPA", "CI/CD"
    ]
    skills = [skill for skill in skills_keywords if skill.lower() in description.lower()]
    return skills
