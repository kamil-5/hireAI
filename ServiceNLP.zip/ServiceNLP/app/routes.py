from fastapi import APIRouter, HTTPException, UploadFile, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from app.db.database import get_db_connection
from app.nlp.utils import analyze_cv, extract_skills_from_offer

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def main_page(request: Request):
    """Afficher la page principale."""
    return templates.TemplateResponse("index.html", {"request": request})


@router.get("/offers", response_class=HTMLResponse)
async def view_offers(request: Request):
    """Afficher les offres d'emploi disponibles."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT JOB_TITLE, COMPANY_NAME, LOCATION, SALARY, REQUIRED_SKILLS, JOB_DESCRIPTION, POSTED_DATE
            FROM RECRUITAI_DB.PUBLIC.JOB_OFFERS
        """)
        offers = [
            {
                "job_title": row[0] or "Non spécifié",
                "company_name": row[1] or "Non spécifié",
                "location": row[2] or "Non spécifié",
                "salary": row[3] or "Non spécifié",
                "required_skills": row[4] or "Non spécifié",
                "job_description": row[5] or "Non spécifié",
                "posted_date": row[6] or "Non spécifié",
            }
            for row in cursor.fetchall()
        ]
        return templates.TemplateResponse("view_offers.html", {"request": request, "offers": offers})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur lors de la récupération des offres : {e}")
    finally:
        cursor.close()
        conn.close()



@router.get("/upload_cv", response_class=HTMLResponse)
async def upload_cv_page(request: Request):
    """Afficher la page de dépôt de CV."""
    return templates.TemplateResponse("upload_cv.html", {"request": request})


@router.post("/upload_cv")
async def upload_cv(file: UploadFile, candidate_id: int = Form(...)):
    """Déposer et analyser un CV."""
    file_path = f"uploaded_cvs/{file.filename}"
    try:
        # Sauvegarder le fichier localement
        with open(file_path, "wb") as f:
            f.write(await file.read())

        # Analyser les compétences
        skills = analyze_cv(file_path)

        # Insérer les informations dans la base de données
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO RECRUITAI_DB.PUBLIC.CVS (CANDIDATE_ID, FILE_PATH) VALUES (%s, %s)",
            (candidate_id, file_path)
        )
        conn.commit()

        return {"message": "CV téléchargé avec succès", "skills": skills}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur lors du téléchargement du CV : {e}")
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()


@router.get("/analyze_offers", response_class=HTMLResponse)
async def analyze_offers_page(request: Request):
    """Analyser les compétences des offres."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM RECRUITAI_DB.PUBLIC.JOB_OFFERS")
        offers = cursor.fetchall()
        offers_data = [
            {
                **dict(zip([col[0] for col in cursor.description], offer)),
                "skills": extract_skills_from_offer(offer[5])  # Analyse des compétences dans la description
            }
            for offer in offers
        ]
        return templates.TemplateResponse("analyze_results.html", {"request": request, "offers": offers_data})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur lors de l'analyse des offres : {e}")
    finally:
        cursor.close()
        conn.close()
